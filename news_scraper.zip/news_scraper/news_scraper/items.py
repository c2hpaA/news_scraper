# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class NewsScraperItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass

class ArticleItem(scrapy.Item):
    tag_name = scrapy.Field()  # Name of the navbar tag
    section_title = scrapy.Field()  # Title of the section
    url = scrapy.Field()  # Article URL
    title = scrapy.Field()  # Article title
    word_number = scrapy.Field()  # Word count
    key_word = scrapy.Field()  # Keywords
    time = scrapy.Field()  # Published time
    article_info = scrapy.Field()  # Additional article info
    content = scrapy.Field()  # Full content of the article
    requires_payment = scrapy.Field()

class SectionItem(scrapy.Item):
    # Existing fields
    tag_name = scrapy.Field()  # The tag associated with the section (e.g., section identifier)
    section_title = scrapy.Field()  # The title of the section (e.g., "Latest News")
    head_href = scrapy.Field()  # The link or URL associated with the section

    # New field to store articles and section info
    articles = scrapy.Field()  # List of articles associated with the section

    # New field for section-specific information like article counts and section IDs
    section_info = scrapy.Field()  # Dictionary of section info, including the section ID and article count



#tfc


class TfcCard(scrapy.Item):
    title = scrapy.Field()  # 文章標題
    categories = scrapy.Field()  # 文章分類（如：錯誤、國際）
    fact_check = scrapy.Field()  # 事實查核結果（錯誤、部分錯誤、事實釐清、正確）
    publish_date = scrapy.Field()  # 發布日期
    link = scrapy.Field()  # 文章連結



class TfcArticleItem(scrapy.Item):
    tag_name = scrapy.Field()  # 固定為 FactCheck
    section_title = scrapy.Field()  # 來自 categories
    url = scrapy.Field()  # 文章 URL
    title = scrapy.Field()  # 文章標題
    word_count = scrapy.Field()  # 文章字數
    keywords = scrapy.Field()  # 文章分類關鍵詞
    publish_time = scrapy.Field()  # 發布日期
    fact_check_info = scrapy.Field()  # 事實查核結論 (錯誤、部分錯誤、事實釐清、正確)
    content = scrapy.Field()  # 文章內容
    requires_payment = scrapy.Field()  # 是否需要付費

