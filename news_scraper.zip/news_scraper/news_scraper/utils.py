import os
import json
import requests
from .settings import SCRAPESOPS_API


def ensure_counter_file_exists(counter_file):
        """Ensure the counter file exists; create it if missing."""
        if not os.path.exists(counter_file):
            print("[INFO] Counter file not found. Creating 'counter.txt' with initial value 1.")
            with open(counter_file, "w") as f:
                f.write("1")

def get_fake_headers():
        """Fetch dynamic fake headers."""
        response = requests.get(
            url="https://headers.scrapeops.io/v1/browser-headers",
            params={
                "api_key": SCRAPESOPS_API,
                "num_results": "2",
            },
        )
        data = response.json()
        if response.status_code == 200 and "result" in data:
            print(f"[INFO] Fetched Headers: {data['result']}")
            return data["result"][0]
        print("[WARNING] Failed to fetch fake headers; using default headers.")
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }


def load_test_counter(counter_file):
        """Load the test counter from file."""
        with open(counter_file, "r") as f:
            try:
                return int(f.read().strip())
            except ValueError:
                print("[WARNING] Invalid content in counter file. Resetting to 1.")
                return 1

def save_test_counter(test_counter,counter_file):
        """Increment and save the updated test counter."""
        test_counter += 1
        with open(counter_file, "w") as f:
            f.write(str(test_counter))


def ensure_directory_exists(file_path):
    """Ensure the directory for a given file path exists."""
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)
        print(f"[INFO] Created directory: {directory}")


#money_udn
def save_section_to_file(section_file, section_data, DEBUG=False):
    """Save section data to a JSON file."""
    try:
        # Ensure the directory exists
        ensure_directory_exists(section_file)

        # If the file doesn't exist, create it with an empty list
        if not os.path.exists(section_file):
            with open(section_file, "w", encoding="utf-8") as f:
                json.dump([], f, ensure_ascii=False, indent=4)

        # Open the file and append new data
        with open(section_file, "r+", encoding="utf-8") as f:
            file_data = json.load(f)  # Load existing data
            
            # Append the new section data, ensuring it's a dictionary
            file_data.append(dict(section_data))  

            # Move the file pointer back to the beginning and write updated data
            f.seek(0)
            json.dump(file_data, f, ensure_ascii=False, indent=4)  # Save back

        if DEBUG:
            print(f"[INFO] Section saved to {section_file}")
    
    except Exception as e:
        if DEBUG:
            print(f"[ERROR] Failed to save Section to {section_file}: {e}")

            
def save_article_to_file(article_file, article_item,DEBUG=False):
    """Save articles to articles.json."""
    try:
        # Ensure the directory exists
        ensure_directory_exists(article_file)

        if not os.path.exists(article_file):  # Create file if not exists
            with open(article_file, "w", encoding="utf-8") as f:
                json.dump([], f)

        with open(article_file, "r+", encoding="utf-8") as f:
            file_data = json.load(f)  # Load existing data
            file_data.append(dict(article_item))  # Append current article
            f.seek(0)
            json.dump(file_data, f, ensure_ascii=False, indent=4)  # Save back
        if DEBUG:
            print(f"[INFO] Article saved to {article_file}")
    except Exception as e:
        if DEBUG:
            print(f"[ERROR] Failed to save article to {article_file}: {e}")



#tfc
def save_tfc_card_to_file(file_path, tfc_card, DEBUG=False):
    """將 TfcCard 物件存入 JSON 檔案"""
    ensure_directory_exists(file_path)

    try:
        if not os.path.exists(file_path):
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump([], f, ensure_ascii=False, indent=4)

        with open(file_path, "r+", encoding="utf-8") as f:
            try:
                file_data = json.load(f)
            except json.JSONDecodeError:
                file_data = []

            file_data.append(dict(tfc_card))  # 轉換為字典後存入
            f.seek(0)
            json.dump(file_data, f, ensure_ascii=False, indent=4)

        if DEBUG:
            print(f"[INFO] 已儲存至 {file_path}")

    except Exception as e:
        if DEBUG:
            print(f"[ERROR] 無法儲存至 {file_path}: {e}")
#

