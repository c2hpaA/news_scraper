import scrapy
import os
import json
import time
import random
from datetime import datetime
from scrapy.selector import Selector
from ..utils import ensure_directory_exists, save_article_to_file, get_fake_headers
from ..items import TfcArticleItem  # 更新為 TfcArticleItem

class TfcSpiderSpider(scrapy.Spider):
    name = "tfc_spider"
    allowed_domains = ["tfc-taiwan.org.tw"]
    start_urls = ["https://tfc-taiwan.org.tw/fact-check-reports-all/"]
    
    def __init__(self, page_limit=None, article_limit=None, DEBUG=False, *args, **kwargs):
        super(TfcSpiderSpider, self).__init__(*args, **kwargs)
        self.DEBUG = DEBUG
        self.headers = get_fake_headers()

        # 設定日期與時間
        current_date = datetime.now().strftime("%Y-%m-%d")
        current_time = datetime.now().strftime("%H-%M-%S")

        # 設定最大頁數與文章數
        self.page_limit = int(page_limit) if page_limit else None
        self.article_limit = int(article_limit) if article_limit else None
        self.article_count = 0  # 追蹤已爬取的文章數
        
        # 創建輸出目錄
        self.output_dir = f"tfc_output/{current_date}"
        ensure_directory_exists(self.output_dir)

        # 設定 JSON 存儲檔案
        self.article_file = f"{self.output_dir}/tfc_article_{current_time}.json"

        # 讀取已存儲的連結，避免重複爬取
        self.seen_links = self.load_existing_links()

    def load_existing_links(self):
        """讀取所有日期資料夾內的 JSON，提取所有已存儲的文章連結"""
        seen_links = set()
        
        # 確保主目錄存在
        if not os.path.exists("tfc_output"):
            return seen_links

        # 遍歷 `tfc_output` 內的所有日期資料夾
        for date_folder in os.listdir("tfc_output"):
            folder_path = os.path.join("tfc_output", date_folder)

            # 確保它是資料夾
            if not os.path.isdir(folder_path):
                continue

            # 遍歷該資料夾內的所有 JSON 檔案
            for filename in os.listdir(folder_path):
                if filename.endswith(".json"):
                    file_path = os.path.join(folder_path, filename)
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            data = json.load(f)
                            if isinstance(data, list):  # 確保 JSON 是列表
                                for entry in data:
                                    if "url" in entry:
                                        seen_links.add(entry["url"])
                    except (json.JSONDecodeError, IOError) as e:
                        if self.DEBUG:
                            print(f"[ERROR] 無法讀取 {file_path}: {e}")

        if self.DEBUG:
            print(f"[INFO] 已讀取 {len(seen_links)} 條歷史連結，避免重複爬取")

        return seen_links

    def start_requests(self):
        """發送初始請求"""
        for url in self.start_urls:
            if self.DEBUG:
                delay = random.uniform(1, 3)
                print(f"[INFO] 等待 {delay:.2f} 秒後請求 {url}")
                time.sleep(delay)
            yield scrapy.Request(url, callback=self.parse_tfc_cards, headers=self.headers, meta={"pg": 0})

    def parse_tfc_cards(self, response):
        """解析事實查核報告列表，並自動翻頁"""
        current_pg = response.meta["pg"]
        has_articles = False  # 標記本頁是否有文章
        
        # 若達到最大頁數，停止爬取
        if self.page_limit and current_pg > self.page_limit:
            if self.DEBUG:
                print(f"[INFO] 已達最大頁數限制 ({self.page_limit})，停止爬取")
            return
        
        # 解析文章區塊
        for article in response.css("li.kb-query-item"):
            has_articles = True  # 如果有解析到文章，則標記為 True
            
            # 解析文章連結
            article_link = article.css("a.kb-advanced-image-link::attr(href)").get()
            article_link = response.urljoin(article_link) if article_link else "未知連結"

            # **檢查是否已經爬取過該文章**
            if article_link in self.seen_links:
                if self.DEBUG:
                    print(f"[INFO] 跳過已爬取文章: {article_link}")
                continue  # 跳過此文章

            # **如果是新文章，則印出**
            print(f"[NEW ARTICLE] {article_link}")

            # 解析文章標題
            title = article.css(".kb-dynamic-html-id-88164_c2c307-ab::text").get()
            title = title.strip() if title else "未知標題"

            # 解析文章分類
            categories = article.css(".wp-block-kadence-dynamiclist a::text").getall()
            categories = [cat.strip() for cat in categories if cat.strip()]
            section_title = "、".join(categories) if categories else "未知分類"

            # 提取 `fact_check_info`
            fact_check_labels = {"錯誤", "部分錯誤", "事實釐清", "正確"}
            fact_check_info = next((cat for cat in categories if cat in fact_check_labels), "未知")

            # 解析發布日期
            publish_date = article.css(".kt-adv-heading88164_cec2e3-a8::text").get()
            publish_date = publish_date.replace("發佈日期：", "").strip() if publish_date else "未知日期"

            # 進入文章頁面爬取詳細資訊
            yield scrapy.Request(
                article_link,
                callback=self.parse_article,
                headers=self.headers,
                meta={
                    "article_link": article_link,
                    "title": title,
                    "categories": categories,
                    "section_title": section_title,
                    "fact_check_info": fact_check_info,
                    "publish_date": publish_date
                }
            )

        # **當沒有找到任何文章時，關閉爬蟲**
        if not has_articles:
            print("[WARNING] 沒有找到任何文章，結束爬取")
            self.crawler.engine.close_spider(self, 'no_articles_found')
            return

        # 繼續爬取下一頁
        next_pg = current_pg + 1
        next_url = f"https://tfc-taiwan.org.tw/fact-check-reports-all/?pg={next_pg}"
        yield scrapy.Request(next_url, callback=self.parse_tfc_cards, headers=self.headers, meta={"pg": next_pg})

    def parse_article(self, response):
        """解析文章詳細內容"""
        url = response.meta["article_link"]
        title = response.meta["title"]
        categories = response.meta["categories"]
        section_title = response.meta["section_title"]
        fact_check_info = response.meta["fact_check_info"]
        publish_time = response.meta["publish_date"]

        # 解析內容
        content_text = "\n\n".join(response.css(".entry-content p::text, .entry-content strong::text, .entry-content h2::text").getall()).strip()
        word_count = len("".join(content_text.split()))  # 計算中文字數
        
        # 建立 `TfcArticleItem`
        article_item = TfcArticleItem(
            tag_name="FactCheck",
            section_title=section_title,
            url=url,
            title=title,
            word_count=word_count,
            keywords=categories,
            publish_time=publish_time,
            fact_check_info=fact_check_info,
            content=content_text,
            requires_payment=False
        )

        self.article_count += 1  # **只有當解析文章成功時，才增加計數**
        save_article_to_file(self.article_file, article_item, self.DEBUG)

        yield article_item


'''
import scrapy
import os
import json
import time
import random
from datetime import datetime
from scrapy.selector import Selector
from ..utils import ensure_directory_exists, save_article_to_file, get_fake_headers
from ..items import TfcArticleItem  # 更新為 TfcArticleItem

class TfcSpiderSpider(scrapy.Spider):
    name = "tfc_spider"
    allowed_domains = ["tfc-taiwan.org.tw"]
    start_urls = ["https://tfc-taiwan.org.tw/fact-check-reports-all/"]
    
    def __init__(self, page_limit=None, article_limit=None, DEBUG=False, *args, **kwargs):
        super(TfcSpiderSpider, self).__init__(*args, **kwargs)
        self.DEBUG = DEBUG
        self.headers = get_fake_headers()

        # 設定日期與時間
        current_date = datetime.now().strftime("%Y-%m-%d")
        current_time = datetime.now().strftime("%H-%M-%S")

        # 設定最大頁數與文章數
        self.page_limit = int(page_limit) if page_limit else None
        self.article_limit = int(article_limit) if article_limit else None
        self.article_count = 0  # 追蹤已爬取的文章數
        
        # 創建輸出目錄
        self.output_dir = f"tfc_output/{current_date}"
        ensure_directory_exists(self.output_dir)

        # 設定 JSON 存儲檔案
        self.article_file = f"{self.output_dir}/tfc_article_{current_time}.json"

        # 讀取已存儲的連結，避免重複爬取
        self.seen_links = self.load_existing_links()

    def load_existing_links(self):
        """讀取所有日期資料夾內的 JSON，提取所有已存儲的文章連結"""
        seen_links = set()
        
        # 確保主目錄存在
        if not os.path.exists("tfc_output"):
            return seen_links

        # 遍歷 `tfc_output` 內的所有日期資料夾
        for date_folder in os.listdir("tfc_output"):
            folder_path = os.path.join("tfc_output", date_folder)

            # 確保它是資料夾
            if not os.path.isdir(folder_path):
                continue

            # 遍歷該資料夾內的所有 JSON 檔案
            for filename in os.listdir(folder_path):
                if filename.endswith(".json"):
                    file_path = os.path.join(folder_path, filename)
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            data = json.load(f)
                            if isinstance(data, list):  # 確保 JSON 是列表
                                for entry in data:
                                    if "url" in entry:
                                        seen_links.add(entry["url"])
                    except (json.JSONDecodeError, IOError) as e:
                        if self.DEBUG:
                            print(f"[ERROR] 無法讀取 {file_path}: {e}")

        if self.DEBUG:
            print(f"[INFO] 已讀取 {len(seen_links)} 條歷史連結，避免重複爬取")

        return seen_links

    def start_requests(self):
        """發送初始請求"""
        for url in self.start_urls:
            if self.DEBUG:
                delay = random.uniform(1, 3)
                print(f"[INFO] 等待 {delay:.2f} 秒後請求 {url}")
                time.sleep(delay)
            yield scrapy.Request(url, callback=self.parse_tfc_cards, headers=self.headers, meta={"pg": 0})

    def parse_tfc_cards(self, response):
        """解析事實查核報告列表，並自動翻頁"""
        current_pg = response.meta["pg"]
        has_articles = False  # 標記本頁是否有文章
        
        # 若達到最大頁數，停止爬取
        if self.page_limit and current_pg > self.page_limit:
            if self.DEBUG:
                print(f"[INFO] 已達最大頁數限制 ({self.page_limit})，停止爬取")
            return
        
        # 解析文章區塊
        for article in response.css("li.kb-query-item"):
            has_articles = True  # 如果有解析到文章，則標記為 True
            
            # 若達到最大文章數，停止爬取
            if self.article_limit and self.article_count >= self.article_limit:
                if self.DEBUG:
                    print(f"[INFO] 已達最大文章數限制 ({self.article_limit})，停止爬取")
                return
            
            # 解析文章連結
            article_link = article.css("a.kb-advanced-image-link::attr(href)").get()
            article_link = response.urljoin(article_link) if article_link else "未知連結"

            # **檢查是否已經爬取過該文章**
            if article_link in self.seen_links:
                if self.DEBUG:
                    print(f"[INFO] 跳過已爬取文章: {article_link}")
                continue  # 跳過此文章
            
            # 解析文章標題
            title = article.css(".kb-dynamic-html-id-88164_c2c307-ab::text").get()
            title = title.strip() if title else "未知標題"

            # 解析文章分類
            categories = article.css(".wp-block-kadence-dynamiclist a::text").getall()
            categories = [cat.strip() for cat in categories if cat.strip()]
            section_title = "、".join(categories) if categories else "未知分類"

            # 提取 `fact_check_info`
            fact_check_labels = {"錯誤", "部分錯誤", "事實釐清", "正確"}
            fact_check_info = next((cat for cat in categories if cat in fact_check_labels), "未知")

            # 解析發布日期
            publish_date = article.css(".kt-adv-heading88164_cec2e3-a8::text").get()
            publish_date = publish_date.replace("發佈日期：", "").strip() if publish_date else "未知日期"

            # 進入文章頁面爬取詳細資訊
            yield scrapy.Request(
                article_link,
                callback=self.parse_article,
                headers=self.headers,
                meta={
                    "article_link": article_link,
                    "title": title,
                    "categories": categories,
                    "section_title": section_title,
                    "fact_check_info": fact_check_info,
                    "publish_date": publish_date
                }
            )

        # 繼續爬取下一頁
        next_pg = current_pg + 1
        next_url = f"https://tfc-taiwan.org.tw/fact-check-reports-all/?pg={next_pg}"
        yield scrapy.Request(next_url, callback=self.parse_tfc_cards, headers=self.headers, meta={"pg": next_pg})

    def parse_article(self, response):
        """解析文章詳細內容"""
        url = response.meta["article_link"]
        title = response.meta["title"]
        categories = response.meta["categories"]
        section_title = response.meta["section_title"]
        fact_check_info = response.meta["fact_check_info"]
        publish_time = response.meta["publish_date"]

        # 解析內容
        content_text = "\n\n".join(response.css(".entry-content p::text, .entry-content strong::text, .entry-content h2::text").getall()).strip()
        # **計算中文字數**
        word_count = len("".join(content_text.split()))  # 移除空格後計算長度
        # 建立 `TfcArticleItem`
        article_item = TfcArticleItem(
            tag_name="FactCheck",
            section_title=section_title,
            url=url,
            title=title,
            word_count=word_count,
            keywords=categories,
            publish_time=publish_time,
            fact_check_info=fact_check_info,
            content=content_text,
            requires_payment=False
        )

        # 儲存 `TfcArticleItem` 到 JSON
        save_article_to_file(self.article_file, article_item, self.DEBUG)

        yield article_item


'''