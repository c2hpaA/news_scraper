import requests
import json
import os
from datetime import datetime

DEBUG = True  # 設定 `DEBUG` 模式

# 設定輸出 JSON 檔案
current_date = datetime.now().strftime("%Y-%m-%d")
current_time = datetime.now().strftime("%H-%M-%S")  # 例如：14-30-45
output_dir = os.path.join("cofact_output", current_date)
os.makedirs(output_dir, exist_ok=True)  # 確保日期資料夾存在
output_file = os.path.join(output_dir, f"cofacts_article_{current_time}.json")

def load_existing_urls():
    """讀取過去的 JSON 紀錄，提取已存儲的文章 `url`，避免重複"""
    seen_urls = set()

    # 確保 `cofact_output` 存在
    if not os.path.exists("cofact_output"):
        return seen_urls

    # 遍歷 `cofact_output` 內的所有日期資料夾
    for date_folder in os.listdir("cofact_output"):
        folder_path = os.path.join("cofact_output", date_folder)

        # 確保它是資料夾
        if not os.path.isdir(folder_path):
            continue

        # 遍歷該資料夾內的所有 JSON 檔案
        for filename in os.listdir(folder_path):
            if filename.endswith(".json"):
                file_path = os.path.join(folder_path, filename)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        if isinstance(data, list):  # 確保 JSON 是列表
                            for entry in data:
                                if "url" in entry:
                                    seen_urls.add(entry["url"])
                except (json.JSONDecodeError, IOError) as e:
                    if DEBUG:
                        print(f"[ERROR] 無法讀取 {file_path}: {e}")

    if DEBUG:
        print(f"[INFO] 已讀取 {len(seen_urls)} 條歷史連結，避免重複爬取")

    return seen_urls

def get_articles():
    """從 Cofacts API 獲取文章資料"""
    url = "https://api.cofacts.tw/graphql"
    query = """
    query MyQuery($first: Int) {
      ListArticles(first: $first) {
        edges {
          node {
            id
            text
            articleReplies {
              reply {
                id
                text
                type
              }
            }
          }
        }
      }
    }
    """
    variables = {"first": 10000}

    response = requests.post(
        url,
        json={"query": query, "variables": variables},
        headers={"Content-Type": "application/json"}
    )

    if response.status_code == 200:
        data = response.json()
        articles = data.get("data", {}).get("ListArticles", {}).get("edges", [])
        if DEBUG:
            print(f"[INFO] 獲取到 {len(articles)} 篇文章")
        return articles
    else:
        print(f"[ERROR] 無法取得文章資料，狀態碼: {response.status_code}")
        return []

def deal_true_or_false(article_replies):
    """判斷文章是否為 `謠言`、`真實` 或 `模糊`"""
    count = {"RUMOR": 0, "NOT_RUMOR": 0, "OPINIONATED": 0}
    text_map = {"RUMOR": [], "NOT_RUMOR": [], "OPINIONATED": []}

    for reply in article_replies:
        reply_type = reply["reply"]["type"]
        reply_text = reply["reply"]["text"]

        if reply_type in count:
            count[reply_type] += 1
            text_map[reply_type].append(reply_text)

    if count["RUMOR"] > count["NOT_RUMOR"]:
        return "Rumor", text_map["RUMOR"]
    elif count["NOT_RUMOR"] > count["RUMOR"]:
        return "Not_Rumor", text_map["NOT_RUMOR"]
    else:
        return "Fuzzy", text_map["OPINIONATED"]

def process_articles(articles):
    """處理並儲存文章至 JSON"""
    processed_data = []
    seen_urls = load_existing_urls()  # 載入過去已存的文章 `url`

    for idx, article in enumerate(articles, start=1):
        content = article["node"]["text"]
        url = f"https://cofacts.tw/article/{article['node']['id']}"

        # **跳過已存在的文章**
        if url in seen_urls:
            if DEBUG:
                print(f"[INFO] 跳過已存在文章: {url}")
            continue

        # **如果是新文章，則印出**
        print(f"[NEW ARTICLE] {url}")

        true_or_false, according_to = deal_true_or_false(article["node"]["articleReplies"])

        article_data = {
            "content": content,
            "url": url,
            "true_or_false": true_or_false,
            "according_to": according_to
        }

        processed_data.append(article_data)

        if DEBUG:
            print(f"[DEBUG] 處理第 {idx} 篇文章: {url}")
            print(f"  - 分類: {true_or_false}")
            print(f"  - 引述: {according_to[:2]} ...")  # 只顯示前兩則評論，避免輸出過長

    if not processed_data:
        print("[WARNING] 沒有新文章，跳過寫入 JSON")
        return

    # 存入 JSON 檔案
    try:
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(processed_data, f, ensure_ascii=False, indent=4)

        if DEBUG:
            print(f"[INFO] 已儲存 {len(processed_data)} 篇新文章至 {output_file}")
    except Exception as e:
        print(f"[ERROR] 無法寫入 JSON 檔案: {e}")

if __name__ == "__main__":
    articles = get_articles()
    if articles:
        process_articles(articles)
    else:
        print("[WARNING] 沒有獲取到文章，無法處理。")
