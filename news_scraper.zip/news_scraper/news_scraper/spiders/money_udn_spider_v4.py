import scrapy
import time
import random
from datetime import datetime
import os
import json
from scrapy.selector import Selector
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from ..items import ArticleItem, SectionItem
from ..utils import ensure_directory_exists, save_test_counter,save_section_to_file,save_article_to_file, get_fake_headers
from ..settings import SCRAPESOPS_API
import requests
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains

class MoneyUdnSpiderV4Spider(scrapy.Spider):
    name = "money_udn_spider_v4"
    allowed_domains = ["money.udn.com"]
    start_urls = ["https://money.udn.com/money/index?from=edn_header"]

    def __init__(self, click_limit=None, article_limit=None, DEBUG=False, *args, **kwargs):
        super(MoneyUdnSpiderV4Spider, self).__init__(click_limit=None, article_limit=None, DEBUG=False, *args, **kwargs)
        # Counter setup
        '''
        self.counter_file = "counter.txt"
        ensure_counter_file_exists(self.counter_file)
        self.test_counter = load_test_counter(self.counter_file)
        self.section_file=f"..//output//section_{self.test_counter}.json"
        self.article_file=f"..//output//article_{self.test_counter}.json"
        '''
        # 取得當前日期與時間
        
        current_date = datetime.now().strftime("%Y-%m-%d")  # 例如：2025-02-03
        current_time = datetime.now().strftime("%H-%M-%S")  # 例如：14-30-45

        # 設定資料夾路徑
        self.output_dir = f"money_udn_output/{current_date}"
        ensure_directory_exists(self.output_dir)
        #os.makedirs(self.output_dir, exist_ok=True)  # 創建日期資料夾（如果不存在）


        
        # 設定 JSON 檔案路徑
        self.section_file = f"{self.output_dir}/section_{current_time}.json"
        self.article_file = f"{self.output_dir}/article_{current_time}.json"
        
        self.custom_settings = {
        "LOG_LEVEL": "DEBUG",
        "LOG_FILE": "debug.log",
        "DOWNLOAD_DELAY": 1.5,
        "AUTOTHROTTLE_ENABLED": True,
        "AUTOTHROTTLE_START_DELAY": 1,
        "AUTOTHROTTLE_MAX_DELAY": 5,
        "AUTOTHROTTLE_TARGET_CONCURRENCY": 1.0,
        
        }
        
        # Track seen URLs
        self.seen_urls = self.load_existing_links()

        # Selenium setup
        chrome_options = Options()
        chrome_options.add_argument("--headless")  # 启用无头模式
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--enable-webgl")
        chrome_options.add_argument("--enable-unsafe-swiftshader")  # 明确启用 WebGL 回退到 SwiftShader
        self.driver = webdriver.Chrome(options=chrome_options)

        # Configurable scraping limits
        self.MAX_ARTICLES = int(article_limit) if article_limit else None
        self.MAX_CLICKS = int(click_limit) if click_limit else None

        self.headers = get_fake_headers()
        self.DEBUG = DEBUG
    def load_existing_links(self):
        """讀取所有日期資料夾內的 JSON，提取所有已存儲的文章連結"""
        seen_links = set()
        
        # 確保主目錄存在
        if not os.path.exists("money_udn_output"):
            print(f"[ERROR] 無法讀取 money_udn_output")
            return seen_links

        # 遍歷 `money_udn_output` 內的所有日期資料夾
        for date_folder in os.listdir("money_udn_output"):
            folder_path = os.path.join("money_udn_output", date_folder)

            # 確保它是資料夾
            if not os.path.isdir(folder_path):
                continue

            # 遍歷該資料夾內的所有 JSON 檔案
            for filename in os.listdir(folder_path):
                if filename.endswith(".json"):
                    file_path = os.path.join(folder_path, filename)
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            data = json.load(f)
                            if isinstance(data, list):  # 確保 JSON 是列表
                                for entry in data:
                                    if "url" in entry:
                                        seen_links.add(entry["url"])
                    except (json.JSONDecodeError, IOError) as e:
                        if self.DEBUG:
                            print(f"[ERROR] 無法讀取 {file_path}: {e}")

        if self.DEBUG:
            print(f"[INFO] 已讀取 {len(seen_links)} 條歷史連結，避免重複爬取")

        return seen_links
    '''
    def get_fake_headers(self):
        """Fetch dynamic fake headers."""
        response = requests.get(
            url="https://headers.scrapeops.io/v1/browser-headers",
            params={
                "api_key": SCRAPESOPS_API,
                "num_results": "2",
            },
        )
        data = response.json()
        if response.status_code == 200 and "result" in data:
            if self.DEBUG:
                print(f"[INFO] Fetched Headers: {data['result']}")
            return data["result"][0]
        print("[WARNING] Failed to fetch fake headers; using default headers.")
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
    '''
    def start_requests(self):
        for url in self.start_urls:
            if self.DEBUG:
                delay = random.uniform(1, 3)
                print(f"[INFO] Sleeping for {delay:.2f} seconds before requesting {url}")
                time.sleep(delay)
            yield scrapy.Request(url, callback=self.parse, headers=self.headers)

    def parse(self, response):
        """Parse homepage and extract navigation links."""
        if self.DEBUG:
            print(f"[INFO] Parsing URL: {response.url}")

        links = response.css("#swiperHeader > nav a::attr(href)").getall()
        tag_names = response.css("#swiperHeader > nav a::text").getall()

        for link, tag_name in zip(links, tag_names):
            head_href = response.urljoin(link)
            delay = random.uniform(1, 3)
            if self.DEBUG:
                print(f"[INFO] Found tag: '{tag_name}', URL: {head_href}")
                print(f"[INFO] Sleeping for {delay:.2f} seconds before requesting section {head_href}")
            time.sleep(delay)

            yield scrapy.Request(
                head_href,
                callback=self.parse_sections,
                meta={"tag_name": tag_name.strip()},
                headers=self.headers
            )
    
    def parse_sections(self, response):
        """Parse category sections and extract articles."""
        tag_name = response.meta["tag_name"]
        head_href = response.url
        if self.DEBUG:
            print(f"[INFO] Parsing sections for tag: '{tag_name}', URL: {head_href}")

        sections = response.css("section.cate-main__section")
        if self.DEBUG:
            print(f"[DEBUG] Found {len(sections)} sections under tag: {tag_name}")
        
        section_info = {}  # To store section info (e.g., section id and article count)
        
        for section in sections:
            section_title = section.css(".story__title span::text").get()
            section_title = section_title.strip() if section_title else None

            if self.DEBUG:
                print(f"[INFO] Found section: '{section_title}'")

            # Dynamically load articles
            articles = self.load_dynamic_articles(response)
            # Deduplicate articles
            articles = [article for article in articles if article["link"] not in self.seen_urls]
            for article in articles:
                self.seen_urls.add(article["link"])

            # Collecting section-related information like article counts
            section_id = section.css("div.showmore.story__read-more::attr(id)").get()
            section_info[section_id] = [
                {"section": section_id, "article_num": len(articles)}
            ]

            # Create a SectionItem
            section_item = SectionItem(
                tag_name=tag_name,
                section_title=section_title,
                head_href=head_href,
                articles=articles,
                section_info=section_info  # Add section_info to the item
            )
            
            # Save section item to file with section_info
            save_section_to_file(self.section_file, section_item, self.DEBUG)
            
            yield section_item

            # Scrape articles' detailed pages
            for article in articles:
                yield scrapy.Request(
                    article["link"],
                    callback=self.parse_article,
                    meta={"tag_name": tag_name, "section_title": section_title},
                    headers=self.headers
                )
    
    
    def load_dynamic_articles(self, response):
        """Load articles dynamically by updating hidden input values for different sections."""
        articles = []
        self.driver.get(response.url)
        sel = Selector(text=self.driver.page_source)
        click_count = 0

        while (self.MAX_CLICKS is None or click_count < self.MAX_CLICKS) and (
            self.MAX_ARTICLES is None or len(articles) < self.MAX_ARTICLES
        ):
            # Extract article items
            article_items = sel.css("ul.story-flex-bt-wrapper li a")
            for item in article_items:
                title = item.css("::attr(title)").get()
                link = item.css("::attr(href)").get()
                time_stamp = item.css(".story__item--time::text").get()
                if title and link:
                    articles.append({
                        "time": time_stamp.strip() if time_stamp else "No Time",
                        "title": title.strip() if title else "No Title",
                        "link": response.urljoin(link),
                    })
            
            if self.DEBUG:
                print(f"[INFO] Loaded {len(articles)} articles so far.")

            # Find all 'showmore' sections with the dynamic IDs
            try:
                showmore_sections = self.driver.find_elements(By.CLASS_NAME, "showmore.story__read-more")
                for section in showmore_sections:
                    # Extract dynamic ID from the section (e.g., "showmore_5648")
                    section_id = section.get_attribute("id")
                    more_id = section_id.replace("showmore", "moreId")  # e.g., "showmore_5648" -> "moreId_5648"

                    # Locate the hidden input field for this section
                    more_id_input = self.driver.find_element(By.ID, more_id)
                    current_value = int(more_id_input.get_attribute("value"))

                    # Update the value of the hidden input field
                    new_value = current_value + 1  # Adjust this based on the number of articles to load
                    self.driver.execute_script(f"document.getElementById('{more_id}').value = {new_value};")

                    # Trigger the necessary event to load more articles (click the 'more' button)
                    more_button = section.find_element(By.CLASS_NAME, "more")
                    ActionChains(self.driver).move_to_element(more_button).click().perform()

                    # Wait for the page to load new articles
                    time.sleep(random.uniform(1, 2))

                    # Check if more articles are available by comparing the values
                    if current_value == new_value:
                        if self.DEBUG:
                            print("[INFO] No more articles to load.")
                        break

                click_count += 1
                sel = Selector(text=self.driver.page_source)

            except Exception as e:
                if self.DEBUG:
                    print(f"[INFO] Error or no more articles: {e}")
                break

        return articles
    def parse_article(self, response):
        
        
        """Parse detailed article content."""
        tag_name = response.meta.get("tag_name", "Unknown")
        section_title = response.meta.get("section_title", "Unknown")

        # Extract article details using multiple methods
        title = response.css("#story_art_title::text").get() or "No Title"
        word_number = response.css("p.article-length::text").get() or "0字"
        key_word = response.css("#article-body > section.article-keyword > ul li a::text").getall() or []
        key_word = [kw.strip() for kw in key_word if kw.strip()]
        time = response.css("#article-body > time::text").get() or "No Time"
        article_info = response.css(".article-body__info span::text").get() or "No Info"
        requires_payment = bool(response.css("div.article-paywall__unpaid"))

        content = {"text": response.css("#article_body p::text").getall()}
        if self.DEBUG:
            print(f"[DEBUG] Parsing article: {title}")
            print(f"[DEBUG] Tag: {tag_name}, Section: {section_title}, URL: {response.url}")
            print(f"[DEBUG] Word Count: {word_number}, Time: {time}")
            print(f"[DEBUG] Keywords: {key_word}")
        article_item = ArticleItem(
            tag_name=tag_name,
            section_title=section_title,
            url=response.url,
            title=title.strip(),
            word_number=word_number.strip(),
            key_word=key_word,
            time=time.strip(),
            article_info=article_info.strip(),
            content=content,
            requires_payment=requires_payment
        )
        save_article_to_file(self.article_file,article_item,self.DEBUG)
        yield article_item

    def closed(self, reason):
        """Save the test counter and close the driver."""
        save_test_counter(self.test_counter, self.counter_file)
        self.driver.quit()
        if self.DEBUG:
            print(f"[INFO] Spider closed.")