import requests
import json
import os
import ssl
import certifi
from datetime import datetime
from requests.adapters import HTTPAdapter
from urllib3.util.ssl_ import create_urllib3_context

DEBUG = True  # 設定 `DEBUG` 模式

# 設定輸出 JSON 檔案
current_date = datetime.now().strftime("%Y-%m-%d")
current_time = datetime.now().strftime("%H-%M-%S")  # 例如：14-30-45
output_dir = os.path.join("line_output", current_date)
os.makedirs(output_dir, exist_ok=True)  # 確保日期資料夾存在
output_file = os.path.join(output_dir, f"line_fact_checker_article_{current_time}.json")

# **設置 `TLS` 版本，防止 `SSL: WRONG_VERSION_NUMBER`**
class TLSAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        context = create_urllib3_context()
        context.set_ciphers('DEFAULT@SECLEVEL=1')  # 降低 `SSL` 安全性等級
        kwargs['ssl_context'] = context
        super().init_poolmanager(*args, **kwargs)

# **設定 `requests` 使用 `certifi` 憑證**
session = requests.Session()
session.mount("https://", TLSAdapter())
session.verify = certifi.where()  # 使用 `certifi` 預設憑證

def load_existing_urls():
    """讀取過去的 JSON 紀錄，提取已存儲的文章 `url`，避免重複"""
    seen_urls = set()

    # 確保 `line_output` 存在
    if not os.path.exists("line_output"):
        return seen_urls

    # 遍歷 `line_output` 內的所有日期資料夾
    for date_folder in os.listdir("line_output"):
        folder_path = os.path.join("line_output", date_folder)

        # 確保它是資料夾
        if not os.path.isdir(folder_path):
            continue

        # 遍歷該資料夾內的所有 JSON 檔案
        for filename in os.listdir(folder_path):
            if filename.endswith(".json"):
                file_path = os.path.join(folder_path, filename)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        if isinstance(data, list):  # 確保 JSON 是列表
                            for entry in data:
                                if "url" in entry:
                                    seen_urls.add(entry["url"])
                except (json.JSONDecodeError, IOError) as e:
                    if DEBUG:
                        print(f"[ERROR] 無法讀取 {file_path}: {e}")

    if DEBUG:
        print(f"[INFO] 已讀取 {len(seen_urls)} 條歷史連結，避免重複爬取")

    return seen_urls

def get_articles(page):
    """從 LINE Fact Checker API 獲取文章資料"""
    url = f"https://api-fact-checker.line-apps.com/pub/v1/zhtw/articles/latest?size=12&sort=updatedAt,desc&page={page}"
    
    try:
        response = session.get(url, timeout=15)  # 設置超時時間
        response.raise_for_status()
        data = response.json()
        
        if data.get("last"):  # 確認是否到最後一頁
            print("[INFO] 已到達最後一頁，停止爬取")
            return None

        articles = data.get("content", [])
        if DEBUG:
            print(f"[INFO] 第 {page} 頁獲取到 {len(articles)} 篇文章")
        return articles
    except requests.exceptions.SSLError as e:
        print(f"[ERROR] SSL 錯誤: {e}")
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] 其他錯誤: {e}")
    return None

def deal_fact_check(article):
    """判斷文章是否為 `謠言`、`真實` 或 `模糊`"""
    if not article.get("comments"):
        accredited = None
    else:
        comment = article["comments"][0]
        accredited = f"{comment['content']} *****url:{comment['url']}"

    tag_map = {
        "Unreal": "Rumor",
        "Partial Real": "Rumor",
        "Real": "Not_Rumor"
    }

    return tag_map.get(article["tag"]["en"], "Fuzzy"), accredited

def process_articles():
    """處理並儲存文章至 JSON"""
    page = 1
    all_articles = []
    seen_urls = load_existing_urls()  # 載入過去已存的文章 `url`

    while True:
        articles = get_articles(page)
        if not articles:
            break

        for idx, article in enumerate(articles, start=1):
            content = article["content"]
            url = f"https://fact-checker.line.me/news?categoryId={article['category']['id']}&articleId={article['id']}"

            # **跳過已存在的文章**
            if url in seen_urls:
                if DEBUG:
                    print(f"[INFO] 跳過已存在文章: {url}")
                continue

            # **如果是新文章，則印出**
            print(f"[NEW ARTICLE] {url}")

            fact_check, according_to = deal_fact_check(article)

            article_data = {
                "content": content,
                "url": url,
                "fact_check": fact_check,
                "according_to": according_to
            }

            all_articles.append(article_data)

            if DEBUG:
                try:
                    print(f"[DEBUG] 處理第 {idx} 篇文章: {url}")
                    print(f"  - 分類: {fact_check}")
                    print(f"  - 引述: {according_to}")
                except UnicodeEncodeError:
                    print("[WARNING] 部分內容包含無法編碼的特殊字元，略過顯示")

        page += 1  # 進入下一頁

    if not all_articles:
        print("[WARNING] 沒有新文章，跳過寫入 JSON")
        return

    # **存入 JSON 檔案**
    try:
        with open(output_file, "w", encoding="utf-8", errors="ignore") as f:
            json.dump(all_articles, f, ensure_ascii=False, indent=4)

        if DEBUG:
            print(f"[INFO] 已儲存 {len(all_articles)} 篇新文章至 {output_file}")
    except Exception as e:
        print(f"[ERROR] 無法寫入 JSON 檔案: {e}")

if __name__ == "__main__":
    process_articles()
