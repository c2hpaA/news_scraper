import os
import json
import csv
import time
import numpy as np
from datetime import datetime

# Path to the folder containing JSON files
json_folder_path = './output'
# Path to the output CSV file (for integrated mode)
current_date = datetime.now().strftime("%Y%m%d")
csv_output_path = f"{json_folder_path}/output_{current_date}.csv"

# Global counter to track processed files
processed_files_count = 0
# Record the start time to calculate the overall update speed
start_time = time.time()

# Store the timestamps to calculate time differences
timestamps = []

# To store update speeds and logs
average_update_speed = []
update_speed_log = []

# List to track processed files (loaded from log file)
processed_files = ["update_speed_log.json"]

# Function to flatten the data and convert all values to string
def flatten(data, parent_key='', sep='_'):
    items = []
    if isinstance(data, dict):
        for k, v in data.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            items.extend(flatten(v, new_key, sep=sep).items())
    elif isinstance(data, list):
        # If the value is a list, join the list into a string with commas separating the elements
        items.append((parent_key, ', '.join(map(str, data))))
    else:
        items.append((parent_key, str(data)))
    return dict(items)


# Function to parse the time field and return a timestamp
def parse_time(time_string):
    try:
        # Assuming the time format is "YYYY/MM/DD HH:MM:SS"
        return datetime.strptime(time_string, "%Y/%m/%d %H:%M:%S")
    except ValueError:
        # In case of invalid or missing time field, return None
        return None


# Function to calculate the update speed based on timestamps
def calculate_update_speed(timestamps):
    if len(timestamps) <= 1:
        return 0  # 若只有一篇文章或沒有文章，則沒有有效的上傳時間差
    
    # Check if timestamps are strings, and convert to datetime objects if necessary
    timestamps = [datetime.strptime(t, "%Y/%m/%d %H:%M:%S") if isinstance(t, str) else t for t in timestamps]
    
    # Calculate the earliest and latest time
    earliest_time = min(timestamps)
    latest_time = max(timestamps)
    
    # Calculate the time difference (latest time - earliest time)
    time_difference = (latest_time - earliest_time).total_seconds()
    
    # Calculate the average upload time: divide the time difference by the number of articles
    average_upload_time = time_difference / len(timestamps) if len(timestamps) > 1 else 0
    average_update_speed.append(average_upload_time)  # Store average upload time for this file
    return average_upload_time  # Return the average upload time (in seconds)


# Function to process a single JSON file
def process_json_file(json_file_path, mode):
    global processed_files_count, timestamps, processed_files

    # Read the JSON data
    with open(json_file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # Skip this file if it's already processed
    json_file_name = os.path.basename(json_file_path)
    if json_file_name in processed_files:
        print(f"Skipping already processed file: {json_file_name}")
        return

    # Mark this file as processed
    processed_files.append(json_file_name)

    # Handle case where the JSON file contains a list of dictionaries
    file_timestamps = []  # Timestamps for this particular file

    if isinstance(data, list):
        for item in data:
            # Extract the time field and convert it to a timestamp
            article_time = item.get('time', None)
            timestamp = parse_time(article_time)

            # Save the timestamp for update speed calculation
            if timestamp:
                file_timestamps.append(timestamp)

            # Flatten the nested structure and save it to CSV
            flattened_data = flatten(item)
            save_to_csv(flattened_data, mode)
    else:
        # Extract the time field and convert it to a timestamp
        article_time = data.get('time', None)
        timestamp = parse_time(article_time)

        # Save the timestamp for update speed calculation
        if timestamp:
            file_timestamps.append(timestamp)

        # Flatten the nested structure and save it to CSV
        flattened_data = flatten(data)
        save_to_csv(flattened_data, mode)

    # Calculate the update speed for this file
    update_speed = calculate_update_speed(file_timestamps)
    
    # Log the update speed for this file in the log list
    log_entry = {
        "file": json_file_path,
        "update_speed": seconds_to_hms(update_speed)
    }
    update_speed_log.append(log_entry)

    processed_files_count += 1


# Function to save data to CSV
def save_to_csv(data, mode='single'):
    global processed_files_count

    # Check if the file exists and create a CSV writer accordingly
    fieldnames = data.keys()

    # If saving to a single CSV file for each JSON
    if mode == 'single':  # One CSV for each JSON file
        output_path = os.path.join(json_folder_path, f"{data['url'].replace('https://', '').replace('/', '_')}.csv")
        with open(output_path, mode='w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerow(data)

    else:  # Integrate all into one CSV file
        if not os.path.exists(csv_output_path):
            with open(csv_output_path, mode='w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()

        with open(csv_output_path, mode='a', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writerow(data)

    processed_files_count += 1


# Function to process all JSON files in the folder
def process_all_json_files(mode='integrated'):
    global processed_files_count, processed_files

    # Check for existing log file and load processed files list
    log_file_path = json_folder_path + '/update_speed_log.json'
    if os.path.exists(log_file_path):
        with open(log_file_path, 'r', encoding='utf-8') as log_file:
            existing_log = json.load(log_file)
            processed_files = [entry["file"] for entry in existing_log]  # Load the list of processed files

    # Get all JSON files in the directory
    for json_file_name in os.listdir(json_folder_path):
        if json_file_name.endswith('.json'):
            json_file_path = os.path.join(json_folder_path, json_file_name)

            # Skip files that have already been processed
            if json_file_name in processed_files:
                print(f"Skipping already processed file: {json_file_name}")
                continue

            # Process the JSON file
            process_json_file(json_file_path, mode)

    # After processing all files, calculate the overall update speed
    overall_update_speed = np.mean(average_update_speed) if average_update_speed else 0
    update_speed_log.append({
        "final_update_speed": seconds_to_hms(overall_update_speed)
    })


# Function to save the log to a JSON file
def save_log_to_json(log_file_path):
    # Save processed_files in the log
    log_data = {
        "processed_files": processed_files,
        "update_speed_log": update_speed_log
    }
    with open(log_file_path, 'w', encoding='utf-8') as log_file:
        json.dump(log_data, log_file, ensure_ascii=False, indent=4)


# Function to convert seconds to HMS format (days:hours:minutes:seconds)
def seconds_to_hms(seconds):
    days = int(seconds // 86400)  # Days
    seconds %= 86400
    hours = int(seconds // 3600)  # Hours
    seconds %= 3600
    minutes = int(seconds // 60)  # Minutes
    remaining_seconds = int(seconds % 60)  # Remaining seconds
    return f"{days:02}:{hours:02}:{minutes:02}:{remaining_seconds:02}"


# Run the script
if __name__ == "__main__":
    # Set mode: 'single' for separate CSV per JSON, 'integrated' for one CSV
    mode = 'integrated'  # Change to 'single' for separate CSV per JSON file
    process_all_json_files(mode=mode)

    # Save the log to a JSON file
    save_log_to_json(json_folder_path + '/update_speed_log.json')

    print(f"Processed {processed_files_count} files. Log saved to: update_speed_log.json")
