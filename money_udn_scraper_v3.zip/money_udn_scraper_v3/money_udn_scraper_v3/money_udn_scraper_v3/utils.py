import os
import json



def ensure_counter_file_exists(counter_file):
        """Ensure the counter file exists; create it if missing."""
        if not os.path.exists(counter_file):
            print("[INFO] Counter file not found. Creating 'counter.txt' with initial value 1.")
            with open(counter_file, "w") as f:
                f.write("1")

def load_test_counter(counter_file):
        """Load the test counter from file."""
        with open(counter_file, "r") as f:
            try:
                return int(f.read().strip())
            except ValueError:
                print("[WARNING] Invalid content in counter file. Resetting to 1.")
                return 1

def save_test_counter(test_counter,counter_file):
        """Increment and save the updated test counter."""
        test_counter += 1
        with open(counter_file, "w") as f:
            f.write(str(test_counter))


def ensure_directory_exists(file_path):
    """Ensure the directory for a given file path exists."""
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)
        print(f"[INFO] Created directory: {directory}")

def save_section_to_file(section_file, section_data,DEBUG=False):
    """Save data to a JSON file."""
    try:
        # Ensure the directory exists
        ensure_directory_exists(section_file)

        if not os.path.exists(section_file):  # Create file if not exists
            with open(section_file, "w", encoding="utf-8") as f:
                json.dump([], f)

        with open(section_file, "r+", encoding="utf-8") as f:
            file_data = json.load(f)  # Load existing data
            file_data.append(dict(section_data))  # Append current article
            f.seek(0)
            json.dump(file_data, f, ensure_ascii=False, indent=4)  # Save back
        if DEBUG:
            print(f"[INFO] Section saved to {section_file}")
    except Exception as e:
        if DEBUG:
            print(f"[ERROR] Failed to save Section to {section_file}: {e}")

def save_article_to_file(article_file, article_item,DEBUG=False):
    """Save articles to articles.json."""
    try:
        # Ensure the directory exists
        ensure_directory_exists(article_file)

        if not os.path.exists(article_file):  # Create file if not exists
            with open(article_file, "w", encoding="utf-8") as f:
                json.dump([], f)

        with open(article_file, "r+", encoding="utf-8") as f:
            file_data = json.load(f)  # Load existing data
            file_data.append(dict(article_item))  # Append current article
            f.seek(0)
            json.dump(file_data, f, ensure_ascii=False, indent=4)  # Save back
        if DEBUG:
            print(f"[INFO] Article saved to {article_file}")
    except Exception as e:
        if DEBUG:
            print(f"[ERROR] Failed to save article to {article_file}: {e}")