# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class MoneyUdnScraperV3Item(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass
class ArticleItem(scrapy.Item):
    tag_name = scrapy.Field()  # Name of the navbar tag
    section_title = scrapy.Field()  # Title of the section
    url = scrapy.Field()  # Article URL
    title = scrapy.Field()  # Article title
    word_number = scrapy.Field()  # Word count
    key_word = scrapy.Field()  # Keywords
    time = scrapy.Field()  # Published time
    article_info = scrapy.Field()  # Additional article info
    content = scrapy.Field()  # Full content of the article
    requires_payment = scrapy.Field()

class SectionItem(scrapy.Item):
    tag_name = scrapy.Field()
    section_title = scrapy.Field()
    head_href = scrapy.Field()
    articles = scrapy.Field() 

'''
class SectionItem(scrapy.Item):
    tag_name = scrapy.Field()
    section_title = scrapy.Field()
    head_href = scrapy.Field()
    articles = scrapy.Field()  # 存储文章的列表

class ArticleItem(scrapy.Item):
    tag_name = scrapy.Field()
    section_title = scrapy.Field()
    url = scrapy.Field()
    title = scrapy.Field()
    word_number = scrapy.Field()
    key_word = scrapy.Field()
    time = scrapy.Field()
    article_info = scrapy.Field()
    content = scrapy.Field()
    requires_payment = scrapy.Field()


'''