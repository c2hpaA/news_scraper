import scrapy
import time
import random
from scrapy.selector import Selector
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from ..items import ArticleItem, SectionItem
from ..utils import ensure_counter_file_exists, load_test_counter, save_test_counter,save_section_to_file,save_article_to_file
from ..settings import SCRAPESOPS_API
import requests



class MoneyUdnSpiderV3Spider(scrapy.Spider):
    name = "money_udn_spider_v3"
    start_urls = ["https://money.udn.com/money/index?from=edn_header"]

    

    def __init__(self, click_limit=None, article_limit=None, DEBUG=False, *args, **kwargs):
        super(MoneyUdnSpiderV3Spider, self).__init__(click_limit=None, article_limit=None, DEBUG=False, *args, **kwargs)
        # Counter setup
        self.counter_file = "counter.txt"
        ensure_counter_file_exists(self.counter_file)
        self.test_counter = load_test_counter(self.counter_file)
        self.section_file=f"..//output//section_{self.test_counter}.json"
        self.article_file=f"..//output//article_{self.test_counter}.json"
        self.custom_settings = {
        "LOG_LEVEL": "DEBUG",
        "LOG_FILE": "debug.log",
        "DOWNLOAD_DELAY": 1.5,
        "AUTOTHROTTLE_ENABLED": True,
        "AUTOTHROTTLE_START_DELAY": 1,
        "AUTOTHROTTLE_MAX_DELAY": 5,
        "AUTOTHROTTLE_TARGET_CONCURRENCY": 1.0,
        
        }
        '''
        not working
        "FEEDS": {
                f".//sections_{self.test_counter}.json": {
                    "format": "json",
                    "encoding": "utf8",
                    "indent": 4,
                    "item_classes": ["SectionItem"],
                    #SectionItem
                },
                f".//articles_{self.test_counter}.json": {
                    "format": "json",
                    "encoding": "utf8",
                    "indent": 4,
                    "item_classes": ["ArticleItem"],
                    #ArticleItem
                },
            }
        '''

        # Selenium setup
        chrome_options = Options()
        chrome_options.add_argument("--headless")  # 启用无头模式
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--enable-webgl")
        chrome_options.add_argument("--enable-unsafe-swiftshader")  # 明确启用 WebGL 回退到 SwiftShader
        self.driver = webdriver.Chrome(options=chrome_options)

        # Configurable scraping limits
        self.MAX_ARTICLES = int(article_limit) if article_limit else None
        self.MAX_CLICKS = int(click_limit) if click_limit else None

        self.headers = self.get_fake_headers()
        self.DEBUG = DEBUG

    def get_fake_headers(self):
        """Fetch dynamic fake headers."""
        response = requests.get(
            url="https://headers.scrapeops.io/v1/browser-headers",
            params={
                "api_key": SCRAPESOPS_API,
                "num_results": "2",
            },
        )
        data = response.json()
        if response.status_code == 200 and "result" in data:
            if self.DEBUG:
                print(f"[INFO] Fetched Headers: {data['result']}")
            return data["result"][0]
        print("[WARNING] Failed to fetch fake headers; using default headers.")
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }

    def start_requests(self):
        for url in self.start_urls:
            if self.DEBUG:
                delay = random.uniform(1, 3)
                print(f"[INFO] Sleeping for {delay:.2f} seconds before requesting {url}")
                time.sleep(delay)
            yield scrapy.Request(url, callback=self.parse, headers=self.headers)

    def parse(self, response):
        """Parse homepage and extract navigation links."""
        if self.DEBUG:
            print(f"[INFO] Parsing URL: {response.url}")

        links = response.css("#swiperHeader > nav a::attr(href)").getall()
        tag_names = response.css("#swiperHeader > nav a::text").getall()

        for link, tag_name in zip(links, tag_names):
            head_href = response.urljoin(link)
            delay = random.uniform(1, 3)
            if self.DEBUG:
                print(f"[INFO] Found tag: '{tag_name}', URL: {head_href}")
                print(f"[INFO] Sleeping for {delay:.2f} seconds before requesting section {head_href}")
            time.sleep(delay)

            yield scrapy.Request(
                head_href,
                callback=self.parse_sections,
                meta={"tag_name": tag_name.strip()},
                headers=self.headers
            )

    def parse_sections(self, response):
        """Parse category sections and extract articles."""
        tag_name = response.meta["tag_name"]
        head_href = response.url
        if self.DEBUG:
            print(f"[INFO] Parsing sections for tag: '{tag_name}', URL: {head_href}")

        sections = response.css("section.cate-main__section")
        if self.DEBUG:
            print(f"[DEBUG] Found {len(sections)} sections under tag: {tag_name}")
        for section in sections:
            section_title = section.css(".story__title span::text").get()
            section_title = section_title.strip() if section_title else None

            if self.DEBUG:
                print(f"[INFO] Found section: '{section_title}'")

            # Dynamically load articles
            articles = self.load_dynamic_articles(response)

            # Create a SectionItem
            section_item = SectionItem(
                tag_name=tag_name,
                section_title=section_title,
                head_href=head_href,
                articles=articles,
            )
            save_section_to_file(self.section_file,section_item,self.DEBUG)
            yield section_item

            for article in articles:
                yield scrapy.Request(
                    article["link"],
                    callback=self.parse_article,
                    meta={"tag_name": tag_name, "section_title": section_title},
                    headers=self.headers
                )

    def load_dynamic_articles(self, response):
        """Load articles dynamically using Selenium."""
        articles = []
        self.driver.get(response.url)
        sel = Selector(text=self.driver.page_source)
        click_count = 0
        while (self.MAX_CLICKS is None or click_count < self.MAX_CLICKS) and (
            self.MAX_ARTICLES is None or len(articles) < self.MAX_ARTICLES
        ):
            article_items = sel.css("ul.story-flex-bt-wrapper li a")
            for item in article_items:
                title = item.css("::attr(title)").get()
                link = item.css("::attr(href)").get()
                time_stamp = item.css(".story__item--time::text").get()
                if title and link:
                    articles.append({
                        "time": time_stamp.strip() if time_stamp else "No Time",
                        "title": title.strip() if title else "No Title",
                        "link": response.urljoin(link),
                    })
            if self.DEBUG:
                print(f"[INFO] Loaded {len(articles)} articles so far.")
            try:
                see_more_button = self.driver.find_element_by_css_selector("span.more")
                see_more_button.click()
                time.sleep(random.uniform(1, 2))
                click_count += 1
                sel = Selector(text=self.driver.page_source)
            except Exception:
                if self.DEBUG:
                    print(f"[INFO] No more 'See more' button or error.")
                break
        return articles

    def parse_article(self, response):
        """Parse detailed article content."""
        tag_name = response.meta.get("tag_name", "Unknown")
        section_title = response.meta.get("section_title", "Unknown")

        # Extract article details using multiple methods
        title = response.css("#story_art_title::text").get() or "No Title"
        word_number = response.css("p.article-length::text").get() or "0字"
        key_word = response.css("#article-body > section.article-keyword > ul li a::text").getall() or []
        key_word = [kw.strip() for kw in key_word if kw.strip()]
        time = response.css("#article-body > time::text").get() or "No Time"
        article_info = response.css(".article-body__info span::text").get() or "No Info"
        requires_payment = bool(response.css("div.article-paywall__unpaid"))

        content = {"text": response.css("#article_body p::text").getall()}
        if self.DEBUG:
            print(f"[DEBUG] Parsing article: {title}")
            print(f"[DEBUG] Tag: {tag_name}, Section: {section_title}, URL: {response.url}")
            print(f"[DEBUG] Word Count: {word_number}, Time: {time}")
            print(f"[DEBUG] Keywords: {key_word}")
        article_item = ArticleItem(
            tag_name=tag_name,
            section_title=section_title,
            url=response.url,
            title=title.strip(),
            word_number=word_number.strip(),
            key_word=key_word,
            time=time.strip(),
            article_info=article_info.strip(),
            content=content,
            requires_payment=requires_payment
        )
        save_article_to_file(self.article_file,article_item,self.DEBUG)
        yield article_item

    def closed(self, reason):
        """Save the test counter and close the driver."""
        save_test_counter(self.test_counter, self.counter_file)
        self.driver.quit()
        if self.DEBUG:
            print(f"[INFO] Spider closed.")