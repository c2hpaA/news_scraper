# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

from scrapy import Spider, Item, Field

class TfcScraperItem(Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass

class FactCheckReportArticle(Item):
    url=Field()
    fact_check = Field()
    title = Field()
    time = Field()
    tag_name = Field()
    question = Field()
    content = Field()
    #background = Field()
    #check_detail = Field()
    #images=Field()
    #links=Field()

'''


class FactCheckReportArticle(scrapy.Item):
    # 文章基本資訊
    source_section = scrapy.Field()  # 來自的主專欄名稱 (例如 "查核報告")
    article_url = scrapy.Field()  # 文章 URL
    title = scrapy.Field()  # 標題
    publication_time = scrapy.Field()  # 發布時間
    tag_name = scrapy.Field()  # 標籤名稱 (例如: "科技資安")
    
    # 查核內容
    fact_check_status = scrapy.Field()  # 事實釐清 (True) 或錯誤 (False)
    question = scrapy.Field()  # 查核問題描述
    content = scrapy.Field()  # 查核簡要內容

    # 詳細內容字段，背景與查核細節分開存儲
    background = scrapy.Field()  # 背景部分，可能包括文字和圖片
    check_details = scrapy.Field()  # 查核細節，可能包括文字、圖片、表格等

    # 附件資訊
    images = scrapy.Field()  # 圖片列表，包括 URL 和描述
    links = scrapy.Field()  # 外部鏈接，包括 URL 和描述
    references = scrapy.Field()  # 引用資料或附註內容
'''