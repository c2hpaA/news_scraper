import os
import json
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from scrapy.http import HtmlResponse
from scrapy import Spider
import scrapy
import requests
from ..items import FactCheckReportArticle

class FactCheckSpider(Spider):
    name = "tfc_spider"
    allowed_domains = ["tfc-taiwan.org.tw"]
    start_urls = ["https://tfc-taiwan.org.tw/articles/report"]

    def __init__(self, page_limit=None, article_limit=None, output_dir="output", *args, **kwargs):
        super(FactCheckSpider, self).__init__(*args, **kwargs)

        # 配置 Selenium WebDriver
        options = Options()
        options.add_argument("--headless")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--window-size=1920x1080")
        self.driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

        # 初始化限制參數
        self.page_limit = int(page_limit) if page_limit else None
        self.article_limit = int(article_limit) if article_limit else None
        self.article_count = 0
        self.page_count = 0
        self.headers=self.get_fake_headers()
        # 初始化輸出文件和目錄
        self.output_dir = output_dir
        self.counter_file = os.path.join(self.output_dir, "counter.txt")
        self.output_file = self.get_output_file_name()
    def get_fake_headers(self):
        """Fetch dynamic fake headers."""
        response = requests.get(
            url="https://headers.scrapeops.io/v1/browser-headers",
            params={
                "api_key": "2ce885a9-78d0-4163-8552-42f8163cb7ab",
                "num_results": "2",
            },
        )
        data = response.json()
        if response.status_code == 200 and "result" in data:
            print(f"[INFO] Fetched Headers: {data['result']}")
            return data["result"][0]
        print("[WARNING] Failed to fetch fake headers; using default headers.")
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
    def ensure_folder_exists(self):
        """確認輸出目錄是否存在，否則創建"""
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
            self.logger.info(f"Created directory: {self.output_dir}")

    def get_output_file_name(self):
        """根據運行計數生成輸出文件名"""
        self.ensure_folder_exists()
        if os.path.exists(self.counter_file):
            with open(self.counter_file, "r") as f:
                counter = int(f.read().strip())
        else:
            counter = 0

        counter += 1
        with open(self.counter_file, "w") as f:
            f.write(str(counter))

        return os.path.join(self.output_dir, f"article_{counter}.json")

    def start_requests(self):
        """初始化 JSON 文件並發起初始請求"""
        with open(self.output_file, "w", encoding="utf-8") as f:
            f.write("[\n")

        yield scrapy.Request(self.start_urls[0], callback=self.parse, headers=self.headers)

    def parse(self, response):
        """處理主頁邏輯，包括提取文章鏈接與分頁"""
        if self.page_limit is not None and self.page_count >= self.page_limit:
            self.logger.info(f"Page limit reached: {self.page_limit}")
            return

        self.page_count += 1
        self.driver.get(response.url)
        rendered_html = self.driver.page_source

        selenium_response = HtmlResponse(
            url=response.url,
            body=rendered_html,
            encoding="utf-8"
        )

        # 提取文章鏈接
        articles = selenium_response.css("h3.entity-list-title a::attr(href)").getall()
        for article_url in articles:
            if self.article_limit is not None and self.article_count >= self.article_limit:
                self.logger.info(f"Article limit reached: {self.article_limit}")
                return

            self.article_count += 1
            full_url = response.urljoin(article_url)
            yield scrapy.Request(full_url, callback=self.parse_article, headers=self.headers)

        # 分頁處理
        next_page = selenium_response.css("li.pager-next a::attr(href)").get()
        if next_page:
            next_page_url = response.urljoin(next_page)
            yield scrapy.Request(next_page_url, callback=self.parse, headers=self.headers)

    def parse_article(self, response):
        """處理文章頁面並保存數據"""
        try:
            self.driver.get(response.url)
            rendered_html = self.driver.page_source

            selenium_response = HtmlResponse(
                url=response.url,
                body=rendered_html,
                encoding="utf-8"
            )

            # 提取圖片和超連結
            images = self.extract_images(selenium_response)
            links = self.extract_links(selenium_response)

            # 提取文章基本信息
            article = FactCheckReportArticle(
                url=response.url,
                #fact_check=selenium_response.css("a[data-class]::text").get() or "未知",
                fact_check=selenium_response.xpath("/html/body/div[1]/main/div/div[2]/div[1]/div/div[2]/div/div/div/div/div/div/div/div[1]/div[1]/div[1]/div[1]/div/div[2]/a/text()").get() or "未知",
                title=selenium_response.css("h2.node-title::text").get() or "無標題",
                time=selenium_response.css("div.submitted::text").get() or "未知時間",
                tag_name=selenium_response.css("div.node-tags div.field-item a::text").get() or "無標籤",
                question=selenium_response.css("span.title::text").get() or "無問題描述",
                content=self.extract_content(selenium_response),
                #background=self.extract_section_content(selenium_response, "背景"),
                #check_detail=self.extract_section_content(selenium_response, "查核"),
                #images=images,
                #links=links
            )

            # 保存數據到 JSON 文件
            '''
            file_data = json.load(f)  # Load existing data
                file_data.append(dict(article_item))  # Append current article
                f.seek(0)
                json.dump(file_data, f, ensure_ascii=False, indent=4)  # Save back
            '''
            with open(self.output_file, "a", encoding="utf-8") as f:
                json.dump(dict(article), f, ensure_ascii=False, indent=4)
                f.write(",\n")
        except Exception as e:
            self.logger.error(f"Failed to process article {response.url}: {e}")

    def extract_section_content(self, sel, section_name):
        """提取指定段落內容，如背景或查核細節"""
        section = sel.xpath(f"//h2[contains(text(), '{section_name}')]/following-sibling::*")
        content = []
        for element in section:
            tag_name = element.root.tag
            if tag_name == "p":  # 提取段落文字
                text = element.css("::text").getall()
                content.append(" ".join(text).strip())
            elif tag_name == "img":  # 提取圖片信息
                img_url = element.css("::attr(src)").get()
                img_alt = element.css("::attr(alt)").get() or ""
                if img_url:
                    content.append({"image": img_url, "alt": img_alt})
            elif tag_name == "a":  # 提取超連結
                link_url = element.css("::attr(href)").get()
                link_text = element.css("::text").get() or ""
                if link_url:
                    content.append({"link": link_url, "text": link_text.strip()})
        return content

    def extract_images(self, sel):
        """提取所有圖片信息"""
        images = []
        for img in sel.css("img"):
            images.append({
                "url": img.css("::attr(src)").get(),
                "alt": img.css("::attr(alt)").get() or ""
            })
        return images

    def extract_links(self, sel):
        """提取所有超連結信息"""
        links = []
        for link in sel.css("a"):
            links.append({
                "url": link.css("::attr(href)").get(),
                "text": link.css("::text").get() or ""
            })
        return links

    def extract_content(self, sel):
        """提取文章主內容"""
        paragraphs = sel.css("div.field-item.even p")
        content = []
        for paragraph in paragraphs:
            text = paragraph.css("::text").getall()
            content.append(" ".join(text).strip())
        return content

    def closed(self, reason):
        """關閉爬蟲時完成 JSON 文件並清理 WebDriver"""
        with open(self.output_file, "rb+") as f:
            f.seek(-3, os.SEEK_END)
            f.truncate()
            f.write(b"\n]")

        if self.driver:
            self.driver.quit()
