import os
import json
import csv
from datetime import datetime
import numpy as np

# Configurations
json_folder_path = './output'  # Directory containing JSON files
current_date = datetime.now().strftime("%Y%m%d")
csv_output_path = f"{json_folder_path}/output_{current_date}.csv"
log_file_path = f"{json_folder_path}/processing_log.json"

# Global variables
processed_files = []  # Track already processed files
update_speed_log = []  # Store update speed information
timestamps = []  # Store timestamps for speed calculation
# To store update speeds and logs
average_update_speed = []
# Function to flatten content and join lists into strings
def flatten_article(article):
    combined_content = "\n".join(article.get('content', []))  # Combine content
    return {
        'url': article.get('url', ''),
        'fact_check': article.get('fact_check', ''),
        'title': article.get('title', ''),
        'time': article.get('time', ''),
        'tag_name': article.get('tag_name', ''),
        'question': article.get('question', ''),
        'content': combined_content
    }

# Function to parse time and return a datetime object
def parse_time(time_string):
    try:
        return datetime.strptime(time_string, "%Y-%m-%d")
    except ValueError:
        return None

# Function to calculate average update speed based on timestamps
def calculate_update_speed(timestamps):
    if len(timestamps) <= 1:
        return 0  # No effective time difference with one or zero articles
    timestamps = sorted(timestamps)
    time_difference = (timestamps[-1] - timestamps[0]).total_seconds()
    return time_difference / len(timestamps)

# Function to process a single JSON file
def process_json_file(json_file_path, csv_writer, mode='integrated'):
    global processed_files, timestamps
    with open(json_file_path, 'r', encoding='utf-8') as f:
        articles = json.load(f)

    file_timestamps = []  # Store timestamps for this file
    for article in articles:
        # Parse time and add to timestamps
        timestamp = parse_time(article.get('time', ''))
        if timestamp:
            file_timestamps.append(timestamp)
        
        # Flatten article and write to CSV
        flattened_article = flatten_article(article)
        if mode == 'single':
            csv_file_name = f"{os.path.splitext(os.path.basename(json_file_path))[0]}.csv"
            single_csv_path = os.path.join(json_folder_path, csv_file_name)
            with open(single_csv_path, 'w', newline='', encoding='utf-8') as single_csv_file:
                writer = csv.DictWriter(single_csv_file, fieldnames=flattened_article.keys())
                writer.writeheader()
                writer.writerow(flattened_article)
        else:
            csv_writer.writerow(flattened_article)

    # Calculate update speed for this file
    update_speed = calculate_update_speed(file_timestamps)
    average_update_speed.append(update_speed)  # Store average upload time for this file
    update_speed_log.append({
        'file': os.path.basename(json_file_path),
        'update_speed_seconds': seconds_to_hms(update_speed)
    })

    processed_files.append(os.path.basename(json_file_path))

# Function to process all JSON files in a directory
def process_all_json_files(mode='integrated'):
    global processed_files, timestamps
    # 檢查並創建目標文件夾
    os.makedirs(json_folder_path, exist_ok=True)
    
    if mode == 'integrated':
        with open(csv_output_path, 'w', newline='', encoding='utf-8') as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=['url', 'fact_check', 'title', 'time', 'tag_name', 'question', 'content'])
            writer.writeheader()
            for file_name in os.listdir(json_folder_path):
                if file_name.endswith('.json') and file_name not in processed_files:
                    process_json_file(os.path.join(json_folder_path, file_name), writer, mode=mode)
    else:
        for file_name in os.listdir(json_folder_path):
            if file_name.endswith('.json') and file_name not in processed_files:
                process_json_file(os.path.join(json_folder_path, file_name), None, mode=mode)

    # Save log
    overall_update_speed = np.mean(average_update_speed) if average_update_speed else 0
    update_speed_log.append({
        "final_update_speed": seconds_to_hms(overall_update_speed)
    })
    with open(log_file_path, 'w', encoding='utf-8') as log_file:
        json.dump({'processed_files': processed_files, 'update_speed_log': update_speed_log}, log_file, ensure_ascii=False, indent=4)

# Function to convert seconds to HMS format (days:hours:minutes:seconds)
def seconds_to_hms(seconds):
    days = int(seconds // 86400)  # Days
    seconds %= 86400
    hours = int(seconds // 3600)  # Hours
    seconds %= 3600
    minutes = int(seconds // 60)  # Minutes
    remaining_seconds = int(seconds % 60)  # Remaining seconds
    return f"{days:02}:{hours:02}:{minutes:02}:{remaining_seconds:02}"
# Run processing
process_all_json_files(mode='integrated')

# Return the paths for verification
csv_output_path, log_file_path
